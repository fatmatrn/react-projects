import ShopCard from "./components/01-shop-card/shop-card";



function App() {
  return (
    <>
   <ShopCard/>
   
    </>
  );
}

export default App;
