import React from "react";
import "./shop-card.scss";
import shopping from "./shopping.json";
import { Card, Col, Row } from "react-bootstrap";

const ShopCard = () => {
  return (
    <Row>
      {shopping.map((shop) => (
        <Col key={shop.id} xs={6} md={4} lg={3} xl={2}>
          <Card style={{ width: "250px" }}>
            <Card.Img height="250px" style={{objectFit:"cover"}} variant="top" src={require(`./shop-card/${shop.image}`)} />
            <Card.Body>
              <Card.Title>Card Title</Card.Title>
              <Card.Text>
                Some quick example text to build on the card title and make up
                the bulk of the card's content.
              </Card.Text>
        
            </Card.Body>
          </Card>
        </Col>
      ))}
    </Row>
  );
};

export default ShopCard;
